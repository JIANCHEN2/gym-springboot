package com;



import java.io.File;
import java.util.Map;

@Controller

@RequestMapping("/mvc")
public class MyController {
    @RequestMapping(value = "/hello")
    public String hello (String name,int age) {
    		System.out.println("教练名字是"+name+",年龄"+age+"岁");
    }
}
