package com;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;


@DempApplication
public class SimpleKafkaForUse implements CommandLineRunner {

    private static final Logger LOG = LoggerFactory.getLogger("DemoApplication");

    @Value("${message.topic.name}")
    private String topicName;

    private final KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    public SimpleKafkaForUse(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public static void main(String[] args) {
        SimpleKafkaForUse.run(SimpleKafkaForUse.class, args);
    }

    @Override
    public void run(String... strings) {
        kafkaTemplate.send(topicName, "Hello Geek!");
        LOG.info("Published message to topic: {}.", topicName);
    }

    @KafkaListener(topics = "javacodegeeks", groupId = "jcg-group")
    public void listen(String message) {
        LOG.info("Received message in JCG group: {}", message);
    }

}